import React from 'react'
import logo from '../images/logo.svg'
export default function Navbar() {
  return (
    <div>
      <nav className="navbar navbar-expand-lg bg-light nav-col">
  <div className="container">
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <a className="navbar-brand" href="/">
      <img src={logo} alt="" className='logo'/>
    </a>
    <div className="collapse navbar-collapse" id="navbarTogglerDemo03">
      <ul className="navbar-nav me-auto mb-2 mb-lg-0">
        <li className="nav-item">
          <a className="nav-link active text-white" aria-current="page" href="/">SIGN UP</a>
        </li>
        <li className="nav-item">
          <a className="nav-link active text-white" aria-current="page" href="/">DASHBOARD</a>
        </li>
        
      </ul>
      </div>
  </div>
</nav>
    </div>
  )
}
