import React from 'react'
import Navbar from './Navbar'
export default function Header() {
  return (
    <div className="wrapper">
<Navbar/>
<div className="container">
<div className="row mt-5">
  <h1 className='text-white'>
ENTERPRISE SOFTWARE DEVELOPMENT 
  </h1>
</div>
</div>
<div className="container">
  <div className="row mt-5">
    <h4 className='text-white'>
    Use the expertise and deep tech background of the best minds at Intellectsoft to create a comprehensive IT strategy for a digital and technological transformation of your organization that goes in line with your business objectives. Our strategic IT consulting will help you automate and digitalise operations, optimise the software portfolio, and implement the latest technologies.
    </h4>
  </div>
</div>
<div className="container my-5">
  <div className="row mt-5 more-row">
  <button type="button" className="btn btn-outline-light more">SIGN IN</button>
  </div>
</div>
</div>
  )
}
